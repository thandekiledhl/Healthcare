<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Patient</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f7fa;
            margin: 0;
            padding: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        h1, h2 {
            color: #2c3e50;
            margin-top: 20px;
        }

        form {
            background-color: #ffffff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 500px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            color: #34495e;
        }

        input[type="text"], input[type="number"] {
            width: 100%;
            padding: 8px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 14px;
        }

        input[type="submit"] {
            background-color: #27ae60;
            color: white;
            border: none;
            padding: 10px 15px;
            font-size: 16px;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        input[type="submit"]:hover {
            background-color: #2ecc71;
        }

        .message {
            text-align: center;
            margin-top: 20px;
            color: #2ecc71;
            font-weight: bold;
        }

        .message.error {
            color: #e74c3c;
        }

        .back-link {
            text-decoration: none;
            color: white;
            background-color: #3498db;
            padding: 10px 15px;
            border-radius: 4px;
            font-size: 16px;
            transition: background-color 0.3s ease;
            margin-top: 20px;
        }

        .back-link:hover {
            background-color: #2980b9;
        }
    </style>
</head>
<body>
    <?php
    include 'db.php';
    if (isset($_GET['id'])) {
        $stmt = $pdo->prepare('SELECT * FROM patients WHERE id = ?');
        $stmt->execute([$_GET['id']]);
        $patient = $stmt->fetch(PDO::FETCH_ASSOC);
    }

    if (isset($_POST['update'])) {
        $stmt = $pdo->prepare('UPDATE patients SET name = ?, age = ?, heart_rate = ?, oxygen_level = ? WHERE id = ?');
        $stmt->execute([$_POST['name'], $_POST['age'], $_POST['heart_rate'], $_POST['oxygen_level'], $_POST['id']]);
        echo "<div class='message'>Patient updated successfully!</div>";
    }
    ?>

    <h2>Update Patient</h2>
    <form method="POST">
        <input type="hidden" name="id" value="<?= $patient['id'] ?>">
        <label for="name">Name: <input type="text" name="name" value="<?= $patient['name'] ?>" required></label><br>
        <label for="age">Age: <input type="number" name="age" value="<?= $patient['age'] ?>" required></label><br>
        <label for="heart_rate">Heart Rate: <input type="number" name="heart_rate" value="<?= $patient['heart_rate'] ?>"></label><br>
        <label for="oxygen_level">Oxygen Level: <input type="number" name="oxygen_level" value="<?= $patient['oxygen_level'] ?>"></label><br>
        <input type="submit" name="update" value="Update Patient">
    </form>

    <a href="index.php" class="back-link">Back to Dashboard</a>
</body>
</html>
