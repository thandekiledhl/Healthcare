<?php
// Connect to the database
$conn = new mysqli("localhost", "root", "", "healthcare_patients");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Collect form data
$patientID = $_POST['PatientID'];
$heartRate = $_POST['HeartRate'];
$bloodPressure = $_POST['BloodPressure'];
$spO2 = $_POST['SpO2'];
$temperature = $_POST['Temperature'];
$activityLevel = $_POST['ActivityLevel'];

$sql = "INSERT INTO heartmonitoring (PatientID, HeartRate, BloodPressure, SpO2, Temperature, ActivityLevel)
        VALUES ('$patientID', '$heartRate', '$bloodPressure', '$spO2', '$temperature', '$activityLevel')";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();

// Redirect back to index.php
header("Location: index.php");
exit();
?>
