<?php
// Connect to the database
include 'db.php';

if (isset($_GET['id'])) {
    $stmt = $pdo->prepare('DELETE FROM heartmonitoring WHERE id = ?');
    $stmt->execute([$_GET['id']]);
    echo "Vital sign record deleted successfully!";
    header("Location: view_vital_signs.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Vital Sign</title>
</head>
<body>
    <h2>Vital Sign Deleted</h2>
    <p>The vital sign record has been deleted successfully.</p>
    <a href="view_vital_signs.php">Back to Vital Signs</a>
</body>
</html>
