<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add New Patient</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f7fa;
            margin: 0;
            padding: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
            height: 100vh;
            box-sizing: border-box;
        }

        h2 {
            text-align: center;
            color: #2c3e50;
            margin-top: 20px;
        }

        form {
            background-color: #ffffff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 500px;
            box-sizing: border-box;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            color: #34495e;
        }

        input[type="text"], input[type="number"] {
            width: 100%;
            padding: 8px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 14px;
        }

        input[type="submit"], .back-button {
            background-color: #27ae60;
            color: white;
            border: none;
            padding: 10px 15px;
            font-size: 16px;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        input[type="submit"]:hover, .back-button:hover {
            background-color: #2ecc71;
        }

        .back-button {
            background-color: #3498db;
            margin-top: 15px;
            display: inline-block;
            text-align: center;
            width: 100%;
            max-width: 500px;
        }

        .back-button:hover {
            background-color: #2980b9;
        }

        .message {
            text-align: center;
            margin-top: 20px;
            color: #2ecc71;
            font-weight: bold;
        }
    </style>
</head>
<body>

    <h2>Add New Patient</h2>
    <form action="" method="POST">
        <label for="name">Name: <input type="text" name="name" required></label><br>
        <label for="age">Age: <input type="number" name="age" required></label><br>
        <label for="heart_rate">Heart Rate: <input type="number" name="heart_rate"></label><br>
        <label for="oxygen_level">Oxygen Level: <input type="number" name="oxygen_level"></label><br>
        <input type="submit" name="submit" value="Add Patient">
    </form>

    <a href="index.php" class="back-button">Back to Index</a>

    <?php
    if (isset($_POST['submit'])) {
        include 'db.php';
        $stmt = $pdo->prepare('INSERT INTO patients (name, age, heart_rate, oxygen_level) VALUES (?, ?, ?, ?)');
        $stmt->execute([$_POST['name'], $_POST['age'], $_POST['heart_rate'], $_POST['oxygen_level']]);
        echo "<div class='message'>Patient added successfully!</div>";
    }
    ?>
    
</body>
</html>


