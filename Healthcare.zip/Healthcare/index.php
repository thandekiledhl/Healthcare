<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Healthcare Remote Patient Monitoring Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f7fa;
            margin: 0;
            padding: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        h1 {
            color: #2c3e50;
            margin-top: 20px;
        }

        a, .button {
            text-decoration: none;
            color: white;
            background-color: #3498db;
            padding: 10px 15px;
            border-radius: 4px;
            font-size: 16px;
            transition: background-color 0.3s ease;
            margin-bottom: 20px;
            display: inline-block;
        }

        a:hover, .button:hover {
            background-color: #2980b9;
        }

        table {
            width: 100%;
            max-width: 800px;
            background-color: #ffffff;
            border-collapse: collapse;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            overflow: hidden;
        }

        table thead {
            background-color: #34495e;
            color: white;
        }

        table th, table td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        table th {
            font-weight: bold;
        }

        table tr:hover {
            background-color: #f1f1f1;
        }

        table td a {
            color: #3498db;
            font-weight: bold;
            text-decoration: none;
            padding: 5px 10px;
            border-radius: 4px;
            transition: background-color 0.3s ease;
        }

        table td a:hover {
            background-color: #2980b9;
            color: white;
        }

        table td a:nth-child(1) {
            background-color: #27ae60;
            color: white;
        }

        table td a:nth-child(1):hover {
            background-color: #2ecc71;
        }

        table td a:nth-child(2) {
            background-color: #e74c3c;
            color: white;
        }

        table td a:nth-child(2):hover {
            background-color: #c0392b;
        }

        /* Additional styles for buttons */
        .buttons-container {
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <h1>Healthcare Patient Monitoring Dashboard</h1>
    <a href="add_patient.php">Add New Patient</a>
    
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Age</th>
                <th>Heart Rate</th>
                <th>Oxygen Level</th>
                <th>Last Update</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php
            include 'db.php';
            $stmt = $pdo->query('SELECT * FROM patients');
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                echo "<tr>
                        <td>{$row['id']}</td>
                        <td>{$row['name']}</td>
                        <td>{$row['age']}</td>
                        <td>{$row['heart_rate']}</td>
                        <td>{$row['oxygen_level']}</td>
                        <td>{$row['last_update']}</td>
                        <td>
                            <a href='update_patient.php?id={$row['id']}'>Edit</a> |
                            <a href='delete_patient.php?id={$row['id']}'>Delete</a>
                        </td>
                      </tr>";
            }
            ?>
        </tbody>
    </table>

    <!-- Buttons for vital signs -->
    <div class="buttons-container">
        <a href="add_vital_sign.php" class="button">Add Vital Sign</a>
        <a href="view_vital_signs.php" class="button">View Vital Signs</a>
    </div>
</body>
</html>
