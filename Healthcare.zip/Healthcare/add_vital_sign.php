<?php
// Connect to the database
include 'db.php';

if (isset($_POST['submit'])) {
    // Collect form data
    $patientID = $_POST['PatientID'];
    $heartRate = $_POST['HeartRate'];
    $bloodPressure = $_POST['BloodPressure'];
    $temperature = $_POST['Temperature'];
    $activityLevel = $_POST['ActivityLevel'];
    $timestamp = date('Y-m-d H:i:s'); // Automatically set the current timestamp

    // Prepare the SQL query to prevent SQL injection
    $sql = "INSERT INTO heartmonitoring (PatientID, Timestamp, HeartRate, BloodPressure, Temperature, ActivityLevel)
            VALUES (:PatientID, :Timestamp, :HeartRate, :BloodPressure, :Temperature, :ActivityLevel)";

    // Prepare the statement
    $stmt = $pdo->prepare($sql);

    // Bind the parameters
    $stmt->bindParam(':PatientID', $patientID);
    $stmt->bindParam(':Timestamp', $timestamp);
    $stmt->bindParam(':HeartRate', $heartRate);
    $stmt->bindParam(':BloodPressure', $bloodPressure);
    $stmt->bindParam(':Temperature', $temperature);
    $stmt->bindParam(':ActivityLevel', $activityLevel);

    // Execute the statement
    if ($stmt->execute()) {
        echo "<p>New vital sign record added successfully!</p>";
    } else {
        echo "<p>Error: Unable to add the vital sign record.</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Vital Sign</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f7fa;
            margin: 0;
            padding: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        h2 {
            color: #2c3e50;
            margin-top: 20px;
        }

        form {
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 500px;
        }

        label {
            display: block;
            margin: 10px 0 5px;
        }

        input[type="number"],
        input[type="text"],
        select {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        input[type="submit"] {
            background-color: #3498db;
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        input[type="submit"]:hover {
            background-color: #2980b9;
        }

        p {
            color: #27ae60;
            font-weight: bold;
        }

        .back-btn {
            margin-top: 20px;
            background-color: #95a5a6;
            color: white;
            padding: 10px 15px;
            border-radius: 4px;
            text-decoration: none;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }

        .back-btn:hover {
            background-color: #7f8c8d;
        }
    </style>
</head>
<body>
    <h2>Add New Vital Sign Record</h2>
    <form method="POST">
        <label for="PatientID">Patient ID:</label>
        <input type="number" name="PatientID" required><br>

        <label for="HeartRate">Heart Rate:</label>
        <input type="number" name="HeartRate" required><br>

        <label for="BloodPressure">Blood Pressure:</label>
        <input type="text" name="BloodPressure" required><br>

        <label for="Temperature">Temperature:</label>
        <input type="number" name="Temperature" required><br>

        <label for="ActivityLevel">Activity Level:</label>
        <select name="ActivityLevel" required>
            <option value="resting">Resting</option>
            <option value="walking">Walking</option>
            <option value="running">Running</option>
            <option value="sleeping">Sleeping</option>
        </select><br>

        <input type="submit" name="submit" value="Add Vital Sign">
        <a href="view_vital_signs.php" class="back-btn">View Vitals</a>
    </form>

    <!-- Back to Index Button -->
    <a href="index.php" class="back-btn">Back to Index</a>
</body>
</html>

