<?php
include 'db.php';

if (isset($_GET['id'])) {
    $stmt = $pdo->prepare('DELETE FROM patients WHERE id = ?');
    $stmt->execute([$_GET['id']]);
    echo "Patient deleted successfully!";
    header("Location: index.php");
    exit;
}
?>
