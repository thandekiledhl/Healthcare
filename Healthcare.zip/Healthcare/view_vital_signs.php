<?php
// Connect to the database
include 'db.php';

// Fix for line 6: Use PDO for fetching data
$stmt = $pdo->query('SELECT * FROM heartmonitoring');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Vital Sign Records</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f7fa;
            margin: 0;
            padding: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        h2 {
            color: #2c3e50;
            margin-top: 20px;
        }

        table {
            width: 100%;
            max-width: 1000px;
            background-color: #ffffff;
            border-collapse: collapse;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            overflow: hidden;
        }

        table thead {
            background-color: #34495e;
            color: white;
        }

        table th, table td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        table th {
            font-weight: bold;
        }

        table tr:hover {
            background-color: #f1f1f1;
        }

        table td a {
            color: #3498db;
            font-weight: bold;
            text-decoration: none;
            padding: 5px 10px;
            border-radius: 4px;
            transition: background-color 0.3s ease;
        }

        table td a:hover {
            background-color: #2980b9;
            color: white;
        }

        table td a:nth-child(1) {
            background-color: #27ae60;
            color: white;
        }

        table td a:nth-child(1):hover {
            background-color: #2ecc71;
        }

        table td a:nth-child(2) {
            background-color: #e74c3c;
            color: white;
        }

        table td a:nth-child(2):hover {
            background-color: #c0392b;
        }

        .back-btn {
            margin-top: 20px;
            background-color: #95a5a6;
            color: white;
            padding: 10px 15px;
            border-radius: 4px;
            text-decoration: none;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }

        .back-btn:hover {
            background-color: #7f8c8d;
        }
    </style>
</head>
<body>
    <h2>Vital Sign Records</h2>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Patient ID</th>
                <th>Timestamp</th>
                <th>Heart Rate</th>
                <th>Blood Pressure</th>
                <th>Temperature</th>
                <th>Activity Level</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if ($stmt->rowCount() > 0) {
                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    echo "<tr>
                            <td>{$row['id']}</td>
                            <td>{$row['PatientID']}</td>
                            <td>{$row['Timestamp']}</td>
                            <td>{$row['HeartRate']}</td>
                            <td>{$row['BloodPressure']}</td>
                            <td>{$row['Temperature']}</td>
                            <td>{$row['ActivityLevel']}</td>
                            <td>
                                <a href='edit_vital_sign.php?id={$row['id']}'>Edit</a> |
                                <a href='delete_vital_sign.php?id={$row['id']}'>Delete</a>
                            </td>
                          </tr>";
                }
            } else {
                echo "<tr><td colspan='8'>No records found</td></tr>";
            }
            ?>
        </tbody>
    </table>

    <a href="index.php" class="back-btn">Back to Index</a>
</body>
</html>

<?php
$conn = null; // Close the connection
?>
